
import java.util.Scanner;
public class Hello {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("Informe o valor ganho por hora trabalhada: ");
		float valor = teclado.nextFloat();
		System.out.println("Quantas horas foram trabalhadas?");
		float horas = teclado.nextFloat();
		float valor2;
		valor2=  valor * horas;
		System.out.format("O valor final ganho � de = R$ %1.2f", + valor2);
		
		teclado.close();
		
		
	}

}
