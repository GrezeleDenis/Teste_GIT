package questao56;

import java.util.Scanner;
public class nomeabrev {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		String nome = new String();
		System.out.println("Digite o Nome completo para abreviar!!");
		nome = entrada.nextLine();
		System.out.println("O nome digitado foi: " + 
		nome);
		String [] nomeab = nome.split(" ");
		int tamanho = nomeab.length;
		System.out.println("O nome abreviado �: ");
		for (int i=0; i<tamanho;i++) {
			if(i<1) {
				String abv = nomeab[i];
				abv = Character.toUpperCase(abv.charAt(0))+ abv.substring(1, abv.length());
				System.out.println("O nome abreviado �: " + abv);
			}else if (i== tamanho -1){
				String abv1 = nomeab[i];
				abv1 = Character.toUpperCase(abv1.charAt(0))+ abv1.substring(1, abv1.length());
				System.out.println(abv1);
			}else {
				String abv = nomeab[i];
				System.out.println(abv.toUpperCase().charAt(0)+ ".");
			}
		
		entrada.close();
	}
}

}