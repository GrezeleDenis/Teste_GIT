/*4.3 - Crie um programa, que gera um vetor de 10 n�meros inteiros
  (usando o m�todo random() da classe Math).  Em seguida, calcula e imprime:
	a) Os n�meros gerados;
	b) A soma dos n�meros;
	c) A m�dia aritm�tica dos n�meros pares;
	d) O menor dos n�meros;
	e) O maior dos n�meros.
*/
//import java.util.Scanner;
//import java.util.Random;

public class Ativ43 { 
		public static void main(String[] args) {
			int soma = 0;
			float media;
			int maior = 0;
			int menor = 101;
			
			int vetor[]=new int[10]; 
			for(int cont=0; cont<11; cont++) {
				 int rnd = (int) (1 + Math.random() * 100);
				 vetor[cont] = rnd;
			}
			//a) Os n�meros gerados;
			System.out.println("Os n�meros gerados s�o:");
			for(int cont=0; cont<11; cont++) {
				System.out.println(vetor[cont]);
			}
			//b) A soma dos n�meros;
			for(int cont=0; cont<11; cont++) {
				soma =soma + (vetor[cont]);
	}
			System.out.println("A Soma dos valores do vetor � :" + (soma));
			
			//c) A m�dia aritm�tica dos n�meros pares;
			media = soma/10;
			System.out.println("A m�dia dos valores do vetor �:%.2f" + (media));
			
			//d) O menor dos n�meros;
			
			for(int cont=0; cont<11; cont++) {
				if(vetor[cont] > maior){ 
					maior = vetor[cont];
				}
			}
			System.out.println("Maior valor = "+ maior);
			
			for(int cont=0; cont<11; cont++) {
				if(vetor[cont] < menor) {
					menor = vetor[cont];
				}
		}
			//e) O maior dos n�meros.
			System.out.println("Menor valor = "+ menor);

		}
}
