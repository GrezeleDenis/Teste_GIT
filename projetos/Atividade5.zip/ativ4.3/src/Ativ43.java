/*4.3 - Crie um programa, que gera um vetor de 10 n�meros inteiros
  (usando o m�todo random() da classe Math).  Em seguida, calcula e imprime:
	a) Os n�meros gerados;
	b) A soma dos n�meros;
	c) A m�dia aritm�tica dos n�meros pares;
	d) O menor dos n�meros;
	e) O maior dos n�meros.
*/
//import java.util.Scanner;
//import java.util.Random;

public class Ativ43 { 
		public static void main(String[] args) {
			int soma = 0;
			int somapar = 0;
			float media;
			int maior = 0;
			int menor = 101;
			int i = 0;
			
			int vetor[]=new int[10]; 
			for(int cont=0; cont<10; cont++) {
				 int rnd = (int) (1 + Math.random() * 100);
				 vetor[cont] = rnd;
			}
			//a) Os n�meros gerados;
			System.out.println("Os n�meros gerados s�o:");
			for(int cont=0; cont<10; cont++) {
				System.out.println(vetor[cont]);
			}
			//b) A soma dos n�meros;
			for(int cont=0; cont<10; cont++) {
				soma =soma + (vetor[cont]);
	}
			System.out.println("A Soma dos valores do vetor � :" + (soma));
			
			//c) A m�dia aritm�tica dos n�meros pares;
			for(int cont=0; cont<10; cont++) {
				if(vetor[cont]%2==0) {
					somapar=somapar + vetor[cont];
					i=i+1;
				}
			}
			media = somapar/i;
			System.out.format("A m�dia dos valores pares do vetor �: %1.2f ", + (media));
			
			//d) O menor dos n�meros;
			
			for(int cont=0; cont<10; cont++) {
				if(vetor[cont] < menor) {
					menor = vetor[cont];
				}
		}
			System.out.println("Menor valor = "+ menor);
			
			//e) O maior dos n�meros.
			
			for(int cont=0; cont<10; cont++) {
				if(vetor[cont] > maior){ 
					maior = vetor[cont];
				}
			}
			System.out.println("Maior valor = "+ maior);

		}
}
